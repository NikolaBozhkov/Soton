public class Deer extends Herbivore {

    public Deer(String name, int age) {
        super(name, age);
    }

    public void makeNoise() {
        System.out.println("ieeeeeh...");
    }
}
