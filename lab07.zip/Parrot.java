public class Parrot extends Omnivore {

	public Parrot(String name, int age) {
		super(name, age);
	}
	
	public void makeNoise() {
		System.out.println("Raaagh");
	}
}