public class Tricycle extends Cycle {

    /**
     * Returns all roads except the most narrow ones
     */
    @Override
    public void getAvailableRoads() {

    }

    /**
     * Changes all tires of the tricycle while testing for
     * balancing and offset
     */
    @Override
    public void changeTires() {
        super.changeTires();
    }
}
