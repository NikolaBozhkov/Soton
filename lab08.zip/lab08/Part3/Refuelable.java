public interface Refuelable {
    void refillTank();
}
