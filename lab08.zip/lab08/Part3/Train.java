public class Train extends RoadVehicle implements Refuelable {

    /**
     * Returns the network of rails
     */
    @Override
    public void getAvailableRoads() {

    }

    /**
     * Refills the tank in a train specific way
     */
    @Override
    public void refillTank() {

    }
}
