public class Bicycle extends Cycle {

    /**
     * Returns every single road
     */
    @Override
    public void getAvailableRoads() {

    }

    /**
     * Changes both tires of the bicycle while testing for
     * stability from tire width
     */
    @Override
    public void changeTires() {
        super.changeTires();
    }
}
