public abstract class Transport {

    public abstract void move();
}
