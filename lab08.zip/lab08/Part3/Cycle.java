public abstract class Cycle extends RoadVehicle {

    /**
     * Changes all tires
     */
    public void changeTires() {

    }
}
