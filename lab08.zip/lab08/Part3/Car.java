public class Car extends RoadVehicle implements Refuelable {

    /**
     * Returns only roads suitable for cars
     */
    @Override
    public void getAvailableRoads() {

    }

    /**
     * Refills the tank in a car specific way
     */
    @Override
    public void refillTank() {

    }
}
