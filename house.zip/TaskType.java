/**
 * Holds the types of Tasks a Person can perform
 */
public enum TaskType {
    DO_WASHING,
    BOIL,
    TURN_ON,
    TURN_OFF,
    WASH_DISHES,
    COOK,
    SHOWER;
}
