public enum State {
    ON, OFF
}
